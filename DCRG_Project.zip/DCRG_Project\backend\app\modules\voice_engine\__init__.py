"""
Voice Engine Module (Phase 3).
Coordinates microphone audio ingestion, Faster-Whisper local speech recognition,
Prosody extraction, and Semantic command classification.
"""

from app.modules.voice_engine.schemas import (
    MicrophoneStatus,
    AudioQuality,
    CanonicalCommand,
    SemanticStatus,
    ProsodyMetrics,
    VoiceEvent,
    VoiceSystemStatus,
    CANONICAL_DIRECTION_VECTORS,
)
from app.modules.voice_engine.microphone_service import (
    MicrophoneService,
    microphone_service,
)
from app.modules.voice_engine.whisper_service import (
    WhisperService,
    whisper_service,
    WhisperTranscriptionResult,
)
from app.modules.voice_engine.manager import (
    VoiceManager,
    voice_manager,
)

__all__ = [
    "MicrophoneStatus",
    "AudioQuality",
    "CanonicalCommand",
    "SemanticStatus",
    "ProsodyMetrics",
    "VoiceEvent",
    "VoiceSystemStatus",
    "CANONICAL_DIRECTION_VECTORS",
    "MicrophoneService",
    "microphone_service",
    "WhisperService",
    "whisper_service",
    "WhisperTranscriptionResult",
    "VoiceManager",
    "voice_manager",
]
