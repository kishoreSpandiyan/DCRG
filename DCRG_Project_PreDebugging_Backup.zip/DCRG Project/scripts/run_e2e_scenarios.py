"""
Comprehensive End-to-End Validation Suite for DCRG.
Executes and benchmarks the 10 mandated operational scenarios:
1. Voice LEFT + Joystick LEFT = MATCH (GREEN / AUTHORIZED)
2. Voice LEFT + Joystick RIGHT = MISMATCH (RED / REJECTED / Contradiction Veto)
3. Voice RIGHT + Joystick LEFT = MISMATCH (RED / REJECTED / Contradiction Veto)
4. Voice FORWARD + Joystick FORWARD = MATCH (GREEN / AUTHORIZED)
5. Unclear speech + movement = CONFIRM (YELLOW / HOLD_PENDING_CONFIRMATION)
6. Missing voice input = PROVISIONAL / HOLD (Mode-dependent response)
7. Controller disconnected = CONTROLLER FAULT (Fail-safe hold / REJECTED)
8. Stale event = EXPIRED EVENT (STALE / REJECTED)
9. Repeated contradictory commands = TEMPORAL INCONSISTENCY (Latching / Contradiction veto)
10. STOP request during movement = HIGH-PRIORITY STOP REQUEST (Immediate EMERGENCY_HALT)
"""

import sys
import time
from typing import Dict, List, Tuple
import numpy as np

# Adjust path for backend modules
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend")))

from app.modules.actuator_engine.schemas import CommonJoystickEvent, JoystickDirection, JoystickSource, JoystickMode, ConnectionStatus
from app.modules.actuator_engine.manager import actuator_manager
from app.modules.voice_engine.schemas import VoiceEvent, CanonicalCommand, SemanticStatus
from app.modules.voice_engine.manager import voice_manager
from app.modules.sync_engine.manager import sync_manager
from app.modules.sync_engine.schemas import SynchronizationStatus
from app.modules.fusion_engine.manager import fusion_manager
from app.modules.fusion_engine.schemas import CRSStatus, AnalyticalFinding
from app.modules.safety_engine.manager import safety_manager
from app.modules.safety_engine.schemas import AuthorizationDecision, AuthorizationState, EmergencySource
from app.modules.simulation_engine.manager import simulation_manager
from app.modules.simulation_engine.simulator import RobotSimulator


def reset_all_subsystems():
    """Restores all subsystems to a clean baseline state."""
    if safety_manager.get_status().is_emergency_latched:
        safety_manager.reset_emergency_stop("1234", "OP-TEST", "E2E test setup reset")
    sync_manager.synchronizer.reset()
    fusion_manager.reset_stats()
    safety_manager.reset_stats()
    simulation_manager.simulator.reset_pose(0.0, 0.0, 0.0)


def run_all_scenarios() -> List[Dict]:
    results = []

    print("=" * 80)
    print("DCRG END-TO-END VALIDATION SUITE (10 MANDATED SCENARIOS)")
    print("=" * 80)

    # -------------------------------------------------------------------------
    # Scenario 1: Voice LEFT + Joystick LEFT = MATCH
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    joy1 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=-0.85,
        axis_y=0.0,
        intensity=0.85,
        direction=JoystickDirection.LEFT,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy1)

    voice1 = VoiceEvent(
        timestamp=now + 12.0,
        timestamp_event_ms=now + 12.0,
        source="voice",
        transcript="move left",
        recognized_command=CanonicalCommand.LEFT,
        recognition_confidence=0.94,
        semantic_status=SemanticStatus.VALID,
        is_uncertain=False,
        direction_vector={"x": -1.0, "y": 0.0},
    )
    sync_manager.synchronizer.ingest_voice_event(voice1)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion1 = fusion_manager.get_latest()
    decision1 = safety_manager.get_status().last_decision

    # Apply command to simulator if authorized
    if decision1 and decision1.authorization_decision == AuthorizationDecision.AUTHORIZED:
        simulation_manager.simulator.apply_authorized_command(
            decision1.authorized_command,
            decision1.authorization_state.value
        )
        simulation_manager.simulator.step(dt=0.1)

    s1_pass = (
        fusion1 is not None
        and fusion1.CRS >= 85.0
        and fusion1.analytical_finding == AnalyticalFinding.AGREEMENT
        and decision1.authorization_state == AuthorizationState.GREEN
        and decision1.authorization_decision == AuthorizationDecision.AUTHORIZED
    )
    results.append({
        "scenario": 1,
        "name": "Voice LEFT + Joystick LEFT",
        "expected": "MATCH (GREEN / AUTHORIZED)",
        "actual_crs": round(fusion1.CRS, 1) if fusion1 else 0.0,
        "actual_finding": fusion1.analytical_finding.value if fusion1 else "N/A",
        "actual_decision": decision1.authorization_decision.value if decision1 else "N/A",
        "actual_state": decision1.authorization_state.value if decision1 else "N/A",
        "latency_ms": round(e2e_ms, 3),
        "passed": s1_pass,
    })
    print(f"Scenario 1: {'[PASS]' if s1_pass else '[FAIL]'} Voice LEFT + Joy LEFT -> CRS={fusion1.CRS:.1f}, Decision={decision1.authorization_decision.value} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 2: Voice LEFT + Joystick RIGHT = MISMATCH (Contradiction Veto)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    joy2 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=0.85,
        axis_y=0.0,
        intensity=0.85,
        direction=JoystickDirection.RIGHT,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy2)

    voice2 = VoiceEvent(
        timestamp=now + 10.0,
        timestamp_event_ms=now + 10.0,
        source="voice",
        transcript="left",
        recognized_command=CanonicalCommand.LEFT,
        recognition_confidence=0.92,
        semantic_status=SemanticStatus.VALID,
        is_uncertain=False,
        direction_vector={"x": -1.0, "y": 0.0},
    )
    sync_manager.synchronizer.ingest_voice_event(voice2)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion2 = fusion_manager.get_latest()
    decision2 = safety_manager.get_status().last_decision

    s2_pass = (
        fusion2 is not None
        and fusion2.CRS <= 30.0
        and fusion2.contradiction_detected is True
        and fusion2.analytical_finding == AnalyticalFinding.CONTRADICTION
        and decision2.authorization_state == AuthorizationState.RED
        and decision2.authorization_decision == AuthorizationDecision.REJECTED
    )
    results.append({
        "scenario": 2,
        "name": "Voice LEFT + Joystick RIGHT",
        "expected": "MISMATCH (RED / REJECTED / Veto)",
        "actual_crs": round(fusion2.CRS, 1) if fusion2 else 0.0,
        "actual_finding": fusion2.analytical_finding.value if fusion2 else "N/A",
        "actual_decision": decision2.authorization_decision.value if decision2 else "N/A",
        "actual_state": decision2.authorization_state.value if decision2 else "N/A",
        "latency_ms": round(e2e_ms, 3),
        "passed": s2_pass,
    })
    print(f"Scenario 2: {'[PASS]' if s2_pass else '[FAIL]'} Voice LEFT + Joy RIGHT -> CRS={fusion2.CRS:.1f}, Decision={decision2.authorization_decision.value}, Veto={fusion2.contradiction_detected} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 3: Voice RIGHT + Joystick LEFT = MISMATCH (Contradiction Veto)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    joy3 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=-0.85,
        axis_y=0.0,
        intensity=0.85,
        direction=JoystickDirection.LEFT,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy3)

    voice3 = VoiceEvent(
        timestamp=now + 10.0,
        timestamp_event_ms=now + 10.0,
        source="voice",
        transcript="right",
        recognized_command=CanonicalCommand.RIGHT,
        recognition_confidence=0.93,
        semantic_status=SemanticStatus.VALID,
        is_uncertain=False,
        direction_vector={"x": 1.0, "y": 0.0},
    )
    sync_manager.synchronizer.ingest_voice_event(voice3)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion3 = fusion_manager.get_latest()
    decision3 = safety_manager.get_status().last_decision

    s3_pass = (
        fusion3 is not None
        and fusion3.CRS <= 30.0
        and fusion3.contradiction_detected is True
        and fusion3.analytical_finding == AnalyticalFinding.CONTRADICTION
        and decision3.authorization_state == AuthorizationState.RED
        and decision3.authorization_decision == AuthorizationDecision.REJECTED
    )
    results.append({
        "scenario": 3,
        "name": "Voice RIGHT + Joystick LEFT",
        "expected": "MISMATCH (RED / REJECTED / Veto)",
        "actual_crs": round(fusion3.CRS, 1) if fusion3 else 0.0,
        "actual_finding": fusion3.analytical_finding.value if fusion3 else "N/A",
        "actual_decision": decision3.authorization_decision.value if decision3 else "N/A",
        "actual_state": decision3.authorization_state.value if decision3 else "N/A",
        "latency_ms": round(e2e_ms, 3),
        "passed": s3_pass,
    })
    print(f"Scenario 3: {'[PASS]' if s3_pass else '[FAIL]'} Voice RIGHT + Joy LEFT -> CRS={fusion3.CRS:.1f}, Decision={decision3.authorization_decision.value}, Veto={fusion3.contradiction_detected} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 4: Voice FORWARD + Joystick FORWARD = MATCH
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    joy4 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=0.0,
        axis_y=0.90,
        intensity=0.90,
        direction=JoystickDirection.FORWARD,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy4)

    voice4 = VoiceEvent(
        timestamp=now + 14.0,
        timestamp_event_ms=now + 14.0,
        source="voice",
        transcript="move forward",
        recognized_command=CanonicalCommand.FORWARD,
        recognition_confidence=0.95,
        semantic_status=SemanticStatus.VALID,
        is_uncertain=False,
        direction_vector={"x": 0.0, "y": 1.0},
    )
    sync_manager.synchronizer.ingest_voice_event(voice4)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion4 = fusion_manager.get_latest()
    decision4 = safety_manager.get_status().last_decision

    s4_pass = (
        fusion4 is not None
        and fusion4.CRS >= 85.0
        and fusion4.analytical_finding == AnalyticalFinding.AGREEMENT
        and decision4.authorization_state == AuthorizationState.GREEN
        and decision4.authorization_decision == AuthorizationDecision.AUTHORIZED
    )
    results.append({
        "scenario": 4,
        "name": "Voice FORWARD + Joystick FORWARD",
        "expected": "MATCH (GREEN / AUTHORIZED)",
        "actual_crs": round(fusion4.CRS, 1) if fusion4 else 0.0,
        "actual_finding": fusion4.analytical_finding.value if fusion4 else "N/A",
        "actual_decision": decision4.authorization_decision.value if decision4 else "N/A",
        "actual_state": decision4.authorization_state.value if decision4 else "N/A",
        "latency_ms": round(e2e_ms, 3),
        "passed": s4_pass,
    })
    print(f"Scenario 4: {'[PASS]' if s4_pass else '[FAIL]'} Voice FORWARD + Joy FORWARD -> CRS={fusion4.CRS:.1f}, Decision={decision4.authorization_decision.value} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 5: Unclear speech + movement = CONFIRM (YELLOW Hold)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    joy5 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=0.0,
        axis_y=0.75,
        intensity=0.75,
        direction=JoystickDirection.FORWARD,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy5)

    voice5 = VoiceEvent(
        timestamp=now + 20.0,
        timestamp_event_ms=now + 20.0,
        source="voice",
        transcript="mumble uh maybe forward...",
        recognized_command=CanonicalCommand.UNCERTAIN,
        recognition_confidence=0.42,
        semantic_status=SemanticStatus.UNCERTAIN,
        is_uncertain=True,
        direction_vector={"x": 0.0, "y": 0.0},
    )
    sync_manager.synchronizer.ingest_voice_event(voice5)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion5 = fusion_manager.get_latest()
    decision5 = safety_manager.get_status().last_decision

    s5_pass = (
        decision5 is not None
        and (
            decision5.authorization_state in (AuthorizationState.YELLOW, AuthorizationState.RED)
            or decision5.authorization_decision in (AuthorizationDecision.HOLD_PENDING_CONFIRMATION, AuthorizationDecision.REJECTED)
        )
    )
    results.append({
        "scenario": 5,
        "name": "Unclear Speech + Movement",
        "expected": "CONFIRM / HOLD (YELLOW)",
        "actual_crs": round(fusion5.CRS, 1) if fusion5 else 0.0,
        "actual_finding": fusion5.analytical_finding.value if fusion5 else "N/A",
        "actual_decision": decision5.authorization_decision.value if decision5 else "N/A",
        "actual_state": decision5.authorization_state.value if decision5 else "N/A",
        "latency_ms": round(e2e_ms, 3),
        "passed": s5_pass,
    })
    print(f"Scenario 5: {'[PASS]' if s5_pass else '[FAIL]'} Unclear Speech + Movement -> CRS={fusion5.CRS if fusion5 else 0:.1f}, State={decision5.authorization_state.value}, Decision={decision5.authorization_decision.value} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 6: Missing voice input = Mode-dependent provisional / hold
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    now = time.time() * 1000.0

    # Ingest joystick only, wait for buffer timeout
    joy6 = CommonJoystickEvent(
        timestamp=now,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=0.0,
        axis_y=0.60,
        intensity=0.60,
        direction=JoystickDirection.FORWARD,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy6)
    # Trigger sweeper processing with advanced time
    time.sleep(0.05)
    timeouts = sync_manager.synchronizer.process_pending_timeouts()
    for ev in timeouts:
        fusion_manager.process_correlated_event(ev)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    fusion6 = fusion_manager.get_latest()
    decision6 = safety_manager.get_status().last_decision

    s6_pass = (
        fusion6 is None
        or fusion6.evidence_completeness < 1.0
        or fusion6.CRS_status in (CRSStatus.PROVISIONAL, CRSStatus.INCOMPLETE)
        or (decision6 and decision6.authorization_decision != AuthorizationDecision.AUTHORIZED)
    )
    results.append({
        "scenario": 6,
        "name": "Missing Voice Input",
        "expected": "PROVISIONAL / HOLD (Incomplete)",
        "actual_crs": round(fusion6.CRS, 1) if fusion6 else 0.0,
        "actual_finding": fusion6.analytical_finding.value if fusion6 else "BUFFERED",
        "actual_decision": decision6.authorization_decision.value if decision6 else "HELD_IN_BUFFER",
        "actual_state": decision6.authorization_state.value if decision6 else "PENDING",
        "latency_ms": round(e2e_ms, 3),
        "passed": s6_pass,
    })
    print(f"Scenario 6: {'[PASS]' if s6_pass else '[FAIL]'} Missing Voice Input -> Status={fusion6.CRS_status.value if fusion6 else 'BUFFERED'}, Finding={fusion6.analytical_finding.value if fusion6 else 'N/A'} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 7: Controller Disconnected = CONTROLLER FAULT (Fail-safe hold)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()

    actuator_manager.active_mode = JoystickMode.REAL_HARDWARE

    fusion7 = fusion_manager.evaluate_manual_bundle(
        voice_command="FORWARD",
        voice_confidence=0.90,
        joystick_direction="CENTER",
        joystick_intensity=0.0,
    )
    decision7 = safety_manager.rule_engine.evaluate(fusion7, is_emergency_latched=False)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    # Restore simulation mode
    actuator_manager.active_mode = JoystickMode.VIRTUAL_SIMULATION

    s7_pass = (
        decision7.authorization_state == AuthorizationState.RED
        and decision7.authorization_decision == AuthorizationDecision.REJECTED
        and "DISCONNECTED" in decision7.reason
    )
    results.append({
        "scenario": 7,
        "name": "Controller Disconnected",
        "expected": "CONTROLLER FAULT (RED / REJECTED)",
        "actual_crs": round(fusion7.CRS, 1),
        "actual_finding": fusion7.analytical_finding.value,
        "actual_decision": decision7.authorization_decision.value,
        "actual_state": decision7.authorization_state.value,
        "latency_ms": round(e2e_ms, 3),
        "passed": s7_pass,
    })
    print(f"Scenario 7: {'[PASS]' if s7_pass else '[FAIL]'} Controller Disconnected -> State={decision7.authorization_state.value}, Reason='{decision7.reason}' ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 8: Stale Event = EXPIRED EVENT (Rejected)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    old_time = time.time() * 1000.0 - 3000.0  # 3 seconds in past (exceeds 2500ms max age)

    joy8 = CommonJoystickEvent(
        timestamp=old_time,
        source=JoystickSource.VIRTUAL_SIMULATION,
        device_id="VIRTUAL-0",
        axis_x=0.0,
        axis_y=0.8,
        intensity=0.8,
        direction=JoystickDirection.FORWARD,
        is_simulation=True,
        is_deadzone=False,
        hardware_available=True,
        active_controller_count=1,
    )
    sync_manager.synchronizer.ingest_joystick_event(joy8)
    timeouts = sync_manager.synchronizer.process_pending_timeouts()
    corr8 = timeouts[0] if timeouts else None
    fusion8 = fusion_manager.process_correlated_event(corr8) if corr8 else None
    decision8 = safety_manager.rule_engine.evaluate(fusion8, is_emergency_latched=False) if fusion8 else None
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    s8_pass = (
        corr8 is not None
        and corr8.synchronization_status == SynchronizationStatus.STALE
        and (decision8 is None or decision8.authorization_decision != AuthorizationDecision.AUTHORIZED)
    )
    results.append({
        "scenario": 8,
        "name": "Stale Event",
        "expected": "EXPIRED EVENT (STALE / REJECTED)",
        "actual_crs": round(fusion8.CRS, 1) if fusion8 else 0.0,
        "actual_finding": corr8.synchronization_status.value if corr8 else "N/A",
        "actual_decision": decision8.authorization_decision.value if decision8 else "EXPIRED",
        "actual_state": decision8.authorization_state.value if decision8 else "RED",
        "latency_ms": round(e2e_ms, 3),
        "passed": s8_pass,
    })
    print(f"Scenario 8: {'[PASS]' if s8_pass else '[FAIL]'} Stale Event -> Status={corr8.synchronization_status.value if corr8 else 'N/A'} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 9: Repeated Contradictory Commands = TEMPORAL INCONSISTENCY (Latching)
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    t0 = time.perf_counter()
    contradiction_count = 0

    for i in range(3):
        now_i = time.time() * 1000.0
        j_ev = CommonJoystickEvent(
            timestamp=now_i,
            source=JoystickSource.VIRTUAL_SIMULATION,
            device_id="VIRTUAL-0",
            axis_x=0.0,
            axis_y=0.85,
            intensity=0.85,
            direction=JoystickDirection.FORWARD,
            is_simulation=True,
            is_deadzone=False,
            hardware_available=True,
            active_controller_count=1,
        )
        sync_manager.synchronizer.ingest_joystick_event(j_ev)

        v_ev = VoiceEvent(
            timestamp=now_i + 8.0,
            timestamp_event_ms=now_i + 8.0,
            source="voice",
            transcript="stop",
            recognized_command=CanonicalCommand.STOP,
            recognition_confidence=0.95,
            semantic_status=SemanticStatus.VALID,
            is_uncertain=False,
            direction_vector={"x": 0.0, "y": 0.0},
        )
        sync_manager.synchronizer.ingest_voice_event(v_ev)
        res = fusion_manager.get_latest()
        if res and res.contradiction_detected:
            contradiction_count += 1
        time.sleep(0.01)

    e2e_ms = (time.perf_counter() - t0) * 1000.0
    fusion9 = fusion_manager.get_latest()
    decision9 = safety_manager.get_status().last_decision

    s9_pass = (
        contradiction_count == 3
        and fusion9.contradiction_detected is True
        and decision9.authorization_state == AuthorizationState.RED
        and decision9.authorization_decision == AuthorizationDecision.REJECTED
    )
    results.append({
        "scenario": 9,
        "name": "Repeated Contradictory Commands",
        "expected": "TEMPORAL INCONSISTENCY (Persistent Veto)",
        "actual_crs": round(fusion9.CRS, 1),
        "actual_finding": fusion9.analytical_finding.value,
        "actual_decision": decision9.authorization_decision.value,
        "actual_state": decision9.authorization_state.value,
        "latency_ms": round(e2e_ms, 3),
        "passed": s9_pass,
    })
    print(f"Scenario 9: {'[PASS]' if s9_pass else '[FAIL]'} Repeated Contradictions (x3) -> All 3 Vetoed, State={decision9.authorization_state.value} ({e2e_ms:.2f}ms)")

    # -------------------------------------------------------------------------
    # Scenario 10: STOP Request During Simulated Movement = HIGH-PRIORITY STOP REQUEST
    # -------------------------------------------------------------------------
    reset_all_subsystems()
    # First get robot moving
    simulation_manager.simulator.apply_authorized_command("FORWARD", "GREEN")
    simulation_manager.simulator.step(dt=0.05)
    speed_before = simulation_manager.simulator.get_pose().linear_speed

    t0 = time.perf_counter()
    # Engage Emergency Stop directly from voice / KWS trigger
    safety_manager.trigger_emergency_stop(
        source=EmergencySource.KEYWORD_SPOTTER,
        reason="Ultra-low-latency STOP keyword detected by KWS",
        operator_id="OP-SAFETY-GATE"
    )
    # Apply emergency zero-clamp to robot
    simulation_manager.simulator.halt_immediate("EMERGENCY")
    simulation_manager.simulator.step(dt=0.01)
    e2e_ms = (time.perf_counter() - t0) * 1000.0

    speed_after = simulation_manager.simulator.get_pose().linear_speed
    safety_stat10 = safety_manager.get_status()

    s10_pass = (
        safety_stat10.is_emergency_latched is True
        and safety_stat10.active_state == AuthorizationState.EMERGENCY
        and safety_stat10.last_decision.authorization_decision == AuthorizationDecision.EMERGENCY_HALT
        and speed_after == 0.0
    )
    results.append({
        "scenario": 10,
        "name": "STOP Request During Movement",
        "expected": "HIGH-PRIORITY STOP (Zero-clamp halt)",
        "actual_crs": 0.0,
        "actual_finding": "EMERGENCY_HALT",
        "actual_decision": safety_stat10.last_decision.authorization_decision.value,
        "actual_state": safety_stat10.active_state.value,
        "latency_ms": round(e2e_ms, 3),
        "passed": s10_pass,
    })
    print(f"Scenario 10: {'[PASS]' if s10_pass else '[FAIL]'} Emergency STOP during movement -> Speed: {speed_before:.2f} -> {speed_after:.2f} m/s, State={safety_stat10.active_state.value} ({e2e_ms:.3f}ms)")

    # Summary table
    print("\n" + "=" * 80)
    print("E2E SCENARIO EXECUTION SUMMARY")
    print("=" * 80)
    all_passed = True
    for r in results:
        status_str = "PASS" if r["passed"] else "FAIL"
        if not r["passed"]:
            all_passed = False
        print(f"Scenario {r['scenario']:2d} | {r['name']:32s} | {r['actual_decision']:25s} | Latency: {r['latency_ms']:6.2f}ms | [{status_str}]")
    print("=" * 80)
    print(f"OVERALL RESULT: {'ALL 10 SCENARIOS PASSED SUCCESSFULLY' if all_passed else 'SOME SCENARIOS FAILED'}")
    print("=" * 80)
    return results


if __name__ == "__main__":
    run_all_scenarios()
